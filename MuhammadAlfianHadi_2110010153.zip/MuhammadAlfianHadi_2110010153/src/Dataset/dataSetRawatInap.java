/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Dataset;
import java.util.ArrayList;

/**
 *
 * @author User
 */
public class dataSetRawatInap {
    private ArrayList<String> nomorRawatInap;
    private ArrayList<String> nomorRekamMedis;
    private ArrayList<String> tanggalMasuk;
    private ArrayList<String> tanggalKeluar;
    private ArrayList<String> kamar;
    private ArrayList<String> biaya;
    
     public dataSetRawatInap (){
        nomorRawatInap= new ArrayList<String>();
        nomorRekamMedis= new ArrayList<String>();
        tanggalMasuk= new ArrayList<String>();
        tanggalKeluar= new ArrayList<String>();
        kamar= new ArrayList<String>();
        biaya= new ArrayList<String>();
    }
     
    public void insertnomorRawatInap(String value){
        nomorRawatInap.add(value);
    }
     public ArrayList<String> getDatasetNomorRawatInap(){
        return this.nomorRawatInap;
    }
     
    public void insertnomorRekamMedis(String value){
        nomorRekamMedis.add(value);
    }
     public ArrayList<String> getDatasetNomorRekamMedis(){
        return this.nomorRekamMedis;
    }
     
    public void inserttanggalMasuk(String value){
        tanggalMasuk.add(value);
    }
     public ArrayList<String> getDatasetTanggalMasuk(){
        return this.tanggalMasuk;
    } 
     
     public void inserttanggalKeluar(String value){
        tanggalKeluar.add(value);
    }
     public ArrayList<String> getDatasetTanggalKeluar(){
        return this.tanggalKeluar;
    }  
     
     public void insertkamar(String value){
        kamar.add(value);
    }
     public ArrayList<String> getDatasetKamar(){
        return this.kamar;
    }  
     
     public void insertbiaya(String value){
        biaya.add(value);
    }
     public ArrayList<String> getDatasetBiaya(){
        return this.biaya;
    }  
}

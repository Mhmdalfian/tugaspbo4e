/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Dataset;
import java.util.ArrayList;
/**
 *
 * @author User
 */
public class dataSetJadwalDokter {
    private ArrayList<String> kodeDokter;
    private ArrayList<String> hari;
    private ArrayList<String> jamMulai;
    private ArrayList<String> jamSelesai;
    
    public dataSetJadwalDokter (){
        kodeDokter= new ArrayList<String>();
        hari= new ArrayList<String>();
        jamMulai= new ArrayList<String>();
        jamSelesai= new ArrayList<String>();
    }
    
     public void insertkodeDokter(String value){
        kodeDokter.add(value);
    }
     public ArrayList<String> getDatasetKodeDokter(){
        return this.kodeDokter;
    }
     
     public void inserthari(String value){
        hari.add(value);
    }
     public ArrayList<String> getDatasetHari(){
        return this.hari;
    }
     
     public void insertjamMulai(String value){
        jamMulai.add(value);
    }
     public ArrayList<String> getDatasetJamMulai(){
        return this.jamMulai;
    }
    
      public void insertjamSelesai(String value){
        jamSelesai.add(value);
    }
     public ArrayList<String> getDatasetJamSelesai(){
        return this.jamSelesai;
    }
}

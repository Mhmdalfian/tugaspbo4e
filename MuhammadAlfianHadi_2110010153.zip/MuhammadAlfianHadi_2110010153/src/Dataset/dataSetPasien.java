/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Dataset;
import java.util.ArrayList;

/**
 *
 * @author User
 */
public class dataSetPasien {
    private ArrayList<String> kodePasien;
    private ArrayList<String> namaPasien;
    private ArrayList<String> jenisKelamin;
    private ArrayList<String> alamat;
    private ArrayList<String> noTelepon;
    
    public dataSetPasien (){
        kodePasien= new ArrayList<String>();
        namaPasien= new ArrayList<String>();
        jenisKelamin= new ArrayList<String>();
        alamat= new ArrayList<String>();
        noTelepon= new ArrayList<String>();
    }
    
    public void insertkodePasien(String value){
        kodePasien.add(value);
    }
     public ArrayList<String> getDatasetKodePasien(){
        return this.kodePasien;
    }
     
    public void insertnamaPasien(String value){
        namaPasien.add(value);
    }
     public ArrayList<String> getDatasetNamaPasien(){
        return this.namaPasien;
    }
    
    public void insertjenisKelamin(String value){
        jenisKelamin.add(value);
    }
     public ArrayList<String> getDatasetJenisKelamin(){
        return this.jenisKelamin;
    }
    
    public void insertalamat(String value){
        alamat.add(value);
    }
     public ArrayList<String> getDatasetAlamat(){
        return this.alamat;
    }
    
    public void insertnoTelepon(String value){
        noTelepon.add(value);
    }
     public ArrayList<String> getDatasetNoTelepon(){
        return this.noTelepon;
    }
}

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Dataset;
import java.util.ArrayList;


/**
 *
 * @author User
 */
public class dataSetObat {
    private ArrayList<String> kodeObat;
    private ArrayList<String> namaObat;
    private ArrayList<String> jenisObat;
    private ArrayList<String> harga;
    private ArrayList<Integer> stok;
    
    public dataSetObat (){
        kodeObat= new ArrayList<String>();
        namaObat= new ArrayList<String>();
        jenisObat= new ArrayList<String>();
        harga= new ArrayList<String>();
        stok= new ArrayList<Integer>();
    }
    
    public void insertkodeObat(String value){
        kodeObat.add(value);
    }
     public ArrayList<String> getDatasetKodeObat(){
        return this.kodeObat;
    }
     
    public void insertnamaObat(String value){
        namaObat.add(value);
    }
     public ArrayList<String> getDatasetNamaObat(){
        return this.namaObat;
    }
     
    public void insertjenisObat(String value){
        jenisObat.add(value);
    }
     public ArrayList<String> getDatasetJenisObat(){
        return this.jenisObat;
    } 
    
    public void insertharga(String value){
        harga.add(value);
    }
     public ArrayList<String> getDatasetharga(){
        return this.harga;
    }
     
    public void insertstok(int value){
        stok.add(value);
    }
     public ArrayList<Integer> getDatasetStok(){
        return this.stok;
    } 
}

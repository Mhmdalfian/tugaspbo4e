/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Dataset;
import java.util.ArrayList;

/**
 *
 * @author User
 */
public class dataSetRekamMedis {
    private ArrayList<String> nomorRekamMedis;
    private ArrayList<String> kodePasien;
    private ArrayList<String> kodeDokter;
    private ArrayList<String> tanggal;
    private ArrayList<String> keluhan;
    private ArrayList<String> diagnosa;
    private ArrayList<String> tindakan;
    
    public dataSetRekamMedis(){
        nomorRekamMedis= new ArrayList<String>();
        kodePasien= new ArrayList<String>();
        kodeDokter= new ArrayList<String>();
        tanggal= new ArrayList<String>();
        keluhan= new ArrayList<String>();
        diagnosa= new ArrayList<String>();
        tindakan= new ArrayList<String>();
    }
    
    public void insertnomorRekamMedis(String value){
        nomorRekamMedis.add(value);
    }
     public ArrayList<String> getDatasetNomorRekamMedis(){
        return this.nomorRekamMedis;
    }
    
    public void insertkodePasien(String value){
        kodePasien.add(value);
    }
     public ArrayList<String> getDatasetKodePasien(){
        return this.kodePasien;
    }
     
    public void insertkodeDokter(String value){
        kodeDokter.add(value);
    }
     public ArrayList<String> getDatasetKodeDokter(){
        return this.kodeDokter;
    }
     
    public void inserttanggal(String value){
        tanggal.add(value);
    }
     public ArrayList<String> getDatasetTanggal(){
        return this.tanggal;
    } 
     
    public void insertkeluhan(String value){
        keluhan.add(value);
    }
     public ArrayList<String> getDatasetKeluhan(){
        return this.keluhan;
    } 
     
    public void insertdiagnosa(String value){
        diagnosa.add(value);
    }
     public ArrayList<String> getDatasetDiagnosa(){
        return this.diagnosa;
    }
     
    public void inserttindakan(String value){
        tindakan.add(value);
    }
     public ArrayList<String> getDatasetTindakan(){
        return this.tindakan;
    } 
}

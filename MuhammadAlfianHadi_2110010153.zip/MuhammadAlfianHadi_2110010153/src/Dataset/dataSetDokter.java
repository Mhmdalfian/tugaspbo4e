/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Dataset;
import java.util.ArrayList;

/**
 *
 * @author User
 */
public class dataSetDokter {
    private ArrayList<String> kodeDokter;
    private ArrayList<String> namaDokter;
    private ArrayList<String> spesialisasi;
    private ArrayList<String> noTelepon;
    private ArrayList<String> email;
    
    public dataSetDokter (){
        kodeDokter= new ArrayList<String>();
        namaDokter= new ArrayList<String>();
        spesialisasi= new ArrayList<String>();
        noTelepon= new ArrayList<String>();
        email= new ArrayList<String>();
    }
    
    public void insertkodeDokter(String value){
        kodeDokter.add(value);
    }
     public ArrayList<String> getDatasetKodeDokter(){
        return this.kodeDokter;
    }
     
    public void insertnamaDokter(String value){
        namaDokter.add(value);
    }
     public ArrayList<String> getDatasetNamaDokter(){
        return this.namaDokter;
    }
     
     public void insertspesialis(String value){
        spesialisasi.add(value);
    }
     public ArrayList<String> getDatasetSpesialis(){
        return this.spesialisasi;
    }
     
    public void insertnomorTelepon(String value){
        noTelepon.add(value);
    }
     public ArrayList<String> getDatasetNomorTelepon(){
        return this.noTelepon;
    }
     
    public void insertemail(String value){
        email.add(value);
    }
     public ArrayList<String> getDatasetEmail(){
        return this.email;
    }
}

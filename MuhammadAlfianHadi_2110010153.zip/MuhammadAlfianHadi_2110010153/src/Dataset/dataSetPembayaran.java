/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Dataset;
import java.util.ArrayList;

/**
 *
 * @author User
 */
public class dataSetPembayaran {
    private ArrayList<String> nomorPembayaran;
    private ArrayList<String> nomorRekamMedis;
    private ArrayList<String> tanggal;
    private ArrayList<String> jumlah;
    private ArrayList<String> metodePembayaran;
    
    
    public dataSetPembayaran (){
        nomorPembayaran= new ArrayList<String>();
        nomorRekamMedis= new ArrayList<String>();
        tanggal= new ArrayList<String>();
        jumlah= new ArrayList<String>();
        metodePembayaran= new ArrayList<String>();
    }
    
    public void insertnomorPembayaran(String value){
        nomorPembayaran.add(value);
    }
     public ArrayList<String> getDatasetNomorPembayaran(){
        return this.nomorPembayaran;
    }
    
     public void insertnomorRekamMedis(String value){
        nomorRekamMedis.add(value);
    }
     public ArrayList<String> getDatasetNomorRekamMedis(){
        return this.nomorRekamMedis;
    }
     
    public void inserttanggal(String value){
        tanggal.add(value);
    }
     public ArrayList<String> getDatasetTanggal(){
        return this.tanggal;
    }
    
    public void insertjumlah(String value){
        jumlah.add(value);
    }
     public ArrayList<String> getDatasetJumlah(){
        return this.jumlah;
    }
    
    public void insertmetodePembayaran(String value){
        metodePembayaran.add(value);
    }
     public ArrayList<String> getDatasetMetodePembayaran(){
        return this.metodePembayaran;
    }
}

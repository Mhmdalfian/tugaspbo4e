/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Data;

/**
 *
 * @author User
 */
;

public class Rawat_Inap {
    private String nomorRawatInap;
    private String nomorRekamMedis;
    private String tanggalMasuk;
    private String tanggalKeluar;
    private String kamar;
    private String biaya;

    // Constructor
    public Rawat_Inap(String nomorRawatInap, String nomorRekamMedis, String tanggalMasuk, String tanggalKeluar, String kamar, String biaya) {
        this.nomorRawatInap = nomorRawatInap;
        this.nomorRekamMedis = nomorRekamMedis;
        this.tanggalMasuk = tanggalMasuk;
        this.tanggalKeluar = tanggalKeluar;
        this.kamar = kamar;
        this.biaya = biaya;
    }

    // Getter dan Setter
    public String getNomorRawatInap() {
        return nomorRawatInap;
    }

    public void setNomorRawatInap(String nomorRawatInap) {
        this.nomorRawatInap = nomorRawatInap;
    }

    public String getNomorRekamMedis() {
        return nomorRekamMedis;
    }

    public void setNomorRekamMedis(String nomorRekamMedis) {
        this.nomorRekamMedis = nomorRekamMedis;
    }

    public String getTanggalMasuk() {
        return tanggalMasuk;
    }

    public void setTanggalMasuk(String tanggalMasuk) {
        this.tanggalMasuk = tanggalMasuk;
    }

    public String getTanggalKeluar() {
        return tanggalKeluar;
    }

    public void setTanggalKeluar(String tanggalKeluar) {
        this.tanggalKeluar = tanggalKeluar;
    }

    public String getKamar() {
        return kamar;
    }

    public void setKamar(String kamar) {
        this.kamar = kamar;
    }

    public String getBiaya() {
        return biaya;
    }

    public void setBiaya(String biaya) {
        this.biaya = biaya;
    }

    // Metode lainnya
    public int hitungLamaRawatInap() {
    
        return 0;
    }

    public void cetakInfoRawatInap() {
        System.out.println("Nomor Rawat Inap: " + nomorRawatInap);
        System.out.println("Nomor Rekam Medis: " + nomorRekamMedis);
        System.out.println("Tanggal Masuk: " + tanggalMasuk);
        System.out.println("Tanggal Keluar: " + tanggalKeluar);
        System.out.println("Kamar: " + kamar);
        System.out.println("Biaya: " + biaya);
    }
}


/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Data;

/**
 *
 * @author User
 */


public class Jadwal_Dokter {
    private String kodeDokter;
    private String hari;
    private String jamMulai;
    private String jamSelesai;

    // Constructor
    public Jadwal_Dokter(String kodeDokter, String hari, String jamMulai, String jamSelesai) {
        this.kodeDokter = kodeDokter;
        this.hari = hari;
        this.jamMulai = jamMulai;
        this.jamSelesai = jamSelesai;
    }

    // Getter dan Setter
    public String getKodeDokter() {
        return kodeDokter;
    }

    public void setKodeDokter(String kodeDokter) {
        this.kodeDokter = kodeDokter;
    }

    public String getHari() {
        return hari;
    }

    public void setHari(String hari) {
        this.hari = hari;
    }

    public String getJamMulai() {
        return jamMulai;
    }

    public void setJamMulai(String jamMulai) {
        this.jamMulai = jamMulai;
    }

    public String getJamSelesai() {
        return jamSelesai;
    }

    public void setJamSelesai(String jamSelesai) {
        this.jamSelesai = jamSelesai;
    }

    // Metode lainnya
    public void tambahJadwal(String hari, String jamMulai, String jamSelesai) {
        
    }

    public void hapusJadwal(String hari) {
        
    }

    public void printInfoJadwal() {
        System.out.println("Kode Dokter: " + kodeDokter);
        System.out.println("Hari: " + hari);
        System.out.println("Jam Mulai: " + jamMulai);
        System.out.println("Jam Selesai: " + jamSelesai);
    }
}
